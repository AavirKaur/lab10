import java.io.IOException;

import com.google.gson.Gson;

public class Main {
    public static void main(String[] args) {

        try {
            // Extracted API Key and URL
            String apiKey = APIUtility.getAPIKey();
            String apiUrl = APIUtility.getAPIUrl();

            String imdbId = "tt3896198"; // Example IMDb ID
            String jsonData = APIUtility.callAPI(apiKey, apiUrl, imdbId);
            System.out.println("JSON Data: " + jsonData);

            // Convert JSON to Java object using Gson
            Gson gson = new Gson();
            Movie movie = gson.fromJson(jsonData, Movie.class);
            System.out.println("Movie Title: " + movie.getTitle());
            System.out.println("Release Year: " + movie.getYear());
            // Add more print statements for other attributes as needed
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

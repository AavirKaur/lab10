import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class APIUtility {
    private static final String API_KEY = "fd858a22"; // Extracted API key
    private static final String API_URL = "http://www.omdbapi.com/"; // Extracted API URL
    /* 
    The method callAPI in APIUtility.java is missing proper error handling for HTTP connection.
    Ensure to handle exceptions related to HTTP connection errors.
    */

    // Method to get the API key
    public static String getAPIKey() {
        return API_KEY;
    }

    // Method to get the API URL
    public static String getAPIUrl() {
        return API_URL;
    }

public static String callAPI(String apiKey, String apiUrl, String imdbId) throws IOException {
    String apiRequestUrl = apiUrl + "?i=" + imdbId + "&apikey=" + apiKey;

    try {
        HttpURLConnection connection = (HttpURLConnection) new URL(apiRequestUrl).openConnection();
        connection.setRequestMethod("GET");

        if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                return response.toString();
            }
        } else {
            // Handle non-OK response codes here
            throw new IOException("HTTP error code: " + connection.getResponseCode());
        }

    } catch (IOException e) {
        System.err.println("Error while connecting to API: " + e.getMessage());
        throw e; // Rethrow the exception for higher-level handling
        // Handle IO exceptions here
        System.err.println("Error while connecting to API: " + e.getMessage());
        throw e; // Rethrow the exception for higher-level handling
    }
}
}
